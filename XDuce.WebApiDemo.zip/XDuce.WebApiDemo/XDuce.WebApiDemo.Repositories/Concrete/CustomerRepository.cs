﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XDuce.WebApiDemo.Repositories.Abstract;
using XDuce.WebApiDemo.Repositories.Connection;
using XDuce.WebApiDemo.Repositories.Entities;

namespace XDuce.WebApiDemo.Repositories.Concrete
{
    public class CustomerRepository : ICustomerRepository
    {
        DatabaseContext dbContext = null;

        public CustomerRepository()
        {
            dbContext = new DatabaseContext();
        }

        public int AddCustomer(Customer customer)
        {
            try
            {
                dbContext.Customers.Add(customer);
                dbContext.SaveChanges();
                return customer.Id;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool DeleteCustomer(int id)
        {
            try
            {
                var exCustomer = dbContext.Customers.FirstOrDefault(x => x.Id == id);
                if (exCustomer != null)
                {
                    dbContext.Customers.Remove(exCustomer);
                    dbContext.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public IEnumerable<Customer> GetAllCusotmers()
        {
            try
            {
                return dbContext.Customers.ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Customer GetCustomerById(int id)
        {
            try
            {
                return dbContext.Customers.FirstOrDefault(x => x.Id == id);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool UpdateCustomer(Customer customer)
        {
            try
            {
                var exCustomer = dbContext.Customers.FirstOrDefault(x => x.Id == customer.Id);
                if (exCustomer != null)
                {
                    exCustomer.FirstName = customer.FirstName;
                    exCustomer.LastName = customer.LastName;
                    exCustomer.Email = customer.Email;
                    dbContext.SaveChanges();
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
