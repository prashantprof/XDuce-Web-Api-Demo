﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XDuce.WebApiDemo.Repositories.Connection;
using XDuce.WebApiDemo.Repositories.Entities;

namespace XDuce.WebApiDemo.Repositories
{
    public class DbInitializer : DropCreateDatabaseIfModelChanges<DatabaseContext>
    {
        protected override void Seed(DatabaseContext context)
        {
            var customers = new List<Customer>()
            {
                new Customer(){ Id=1, FirstName="Virat", LastName="Kohli", Email="virat_kohli@india.com", MemberSince=DateTime.Parse("2015-11-22")},
                new Customer(){ Id=2, FirstName="Rohit", LastName="Sharma", Email="rohit_sharma@india.com", MemberSince=DateTime.Parse("2016-08-12")},
                new Customer(){ Id=3, FirstName="Shikhar", LastName="Dhawan", Email="shikhar_dhawan@india.com", MemberSince=DateTime.Parse("2017-03-18")},
                new Customer(){ Id=4, FirstName="Suresh", LastName="Raina", Email="suresh_raina@india.com", MemberSince=DateTime.Parse("2014-03-05") },
                new Customer(){ Id=5, FirstName="Ajinkya", LastName="Rahane", Email="ajinkya_rahane@india.com", MemberSince=DateTime.Parse("2015-11-22") }
            };
        }
    }
}
