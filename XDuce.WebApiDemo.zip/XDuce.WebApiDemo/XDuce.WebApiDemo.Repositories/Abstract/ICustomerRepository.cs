﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XDuce.WebApiDemo.Repositories.Entities;

namespace XDuce.WebApiDemo.Repositories.Abstract
{
    public interface ICustomerRepository
    {
        IEnumerable<Customer> GetAllCusotmers();

        Customer GetCustomerById(int id);

        int AddCustomer(Customer customer);

        bool UpdateCustomer(Customer customer);

        bool DeleteCustomer(int id);
    }
}
