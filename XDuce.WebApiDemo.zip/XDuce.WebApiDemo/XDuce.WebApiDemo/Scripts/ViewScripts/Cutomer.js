﻿
var customer = {
    View: $("#divAddNews"),
    Init: function () {
        var me = customer;
        me.BindEvents();
    },
    BindEvents: function () {
        var me = customer;

        $(".linkEditCustomer").each(function () {
            $(this).click(function () {
                var custId = $(this).data("custId");
                alert('Edit: ' + $(this).data('custId'));
            });
        });

        $("[name='lnkEditCustomer']").off("click");
        $("[name='lnkEditCustomer']").on("click", function (e) {
            e.preventDefault();
            alert('Edit: ' + $(this).data('custId'));
        });

        $("a[name='lnkDeleteCustomer']").off("click");
        $("a[name='lnkDeleteCustomer']").on("click", function (e) {
            e.preventDefault();
            alert('Delete: ' + $(this).data('custId'));
        });

        $("#btnSaveCustomer").off("click");
        $("#btnSaveCustomer").on("click", function (e) {
            e.preventDefault();

            $.validator.unobtrusive.parse($("#frmAddCustomer"));
            $("#frmAddCustomer").validate();
            if ($("#frmAddCustomer").valid()) {
                $("#frmAddCustomer").submit();
            }
            else {
                return false;
            }
        });

        $("#frmAddCustomer").submit(function (evt) {
            evt.preventDefault();

            var customer = {
                Id: $('#Id').val(),
                FirstName: $('#FirstName').val(),
                LastName: $('#LastName').val(),
                Email: $('#Email').val()
            };

            $.ajax({
                url: '/api/customer',
                type: 'POST',
                data: JSON.stringify(customer),
                async: false,
                cache: false,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data, textStatus, xhr) {
                    if (data) {
                        alert('Customer saved successfully.');
                        window.location.href = '/home/index';
                    }
                    else {
                        alert('Unable to save customer in Database.');
                    }
                },
                error: function (xhr, textStatus, errorThrown) {
                    alert('Error in Database');
                }
            });
            return false;
        });
    },
    DeleteCustomer: function (id) {
        var me = customer;
        $.ajax({
            type: "GET",
            url: "/api/customer/DeleteCustomer/" + id,
            timeOut: 3600000,
            success: function (response) {
                alert('Customer deleted successfully.');
                location.reload();
            },
            error: function (response) {

            }
        });
    }
};

$(function () {
    var me = customer;
    me.Init();
});

function formatAction(value, row, index) {
    return "<a data-custId='" + row.Id + "' href='/home/EditCustomer?id=" + row.Id + "' class='linkEditCustomer'><i class='glyphicon glyphicon-edit'></i></a> &nbsp;" +
        "<a data-custId='" + row.Id + "' onclick='DeleteCustomer(" + row.Id + ")'  href='javascript:void(0);' class='linkDeleteCustomer'><i class='glyphicon glyphicon-trash'></i></a>";
}

function DeleteCustomer(id) {
    customer.DeleteCustomer(id);
}