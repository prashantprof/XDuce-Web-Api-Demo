﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using XDuce.WebApiDemo.Models;
using XDuce.WebApiDemo.Services.Abstract;
using XDuce.WebApiDemo.Services.Concrete;

namespace XDuce.WebApiDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICustomerService customerService = null;

        public HomeController() : this(new CustomerService()) { }

        public HomeController(ICustomerService customerService)
        {
            this.customerService = customerService;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddCustomer()
        {
            ViewBag.Title = "Add New Customer";
            return View(new CustomerModel());
        }

        public ActionResult EditCustomer(int id)
        {
            ViewBag.Title = "Edit Customer";
            return View("AddCustomer", customerService.GetCustomerById(id));
        }
    }
}
