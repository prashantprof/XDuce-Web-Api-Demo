﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using XDuce.WebApiDemo.Models;
using XDuce.WebApiDemo.Services.Abstract;
using XDuce.WebApiDemo.Services.Concrete;

namespace XDuce.WebApiDemo.Controllers.api
{
    [RoutePrefix("api/customer")]
    public class CustomerController : ApiController
    {
        private readonly ICustomerService customerService = null;

        public CustomerController() : this(new CustomerService()) { }

        public CustomerController(ICustomerService customerService)
        {
            this.customerService = customerService;
        }

        [HttpGet]
        [Route("GetAllCusotmers")]
        public IEnumerable<CustomerModel> GetAllCusotmers()
        {
            return customerService.GetAllCusotmers();
        }

        [HttpGet]
        [Route("GetCustomerById/{id}")]
        public CustomerModel GetCustomerById(int id)
        {
            return customerService.GetCustomerById(id);
        }

        [HttpPost]
        public bool Post(JObject customer)
        {
            dynamic jsonData = customer;
            var newCustomer = jsonData.ToObject<CustomerModel>();

            if (newCustomer != null && ModelState.IsValid)
            {
                return customerService.SaveCustomer(newCustomer);
            }
            return false;
        }

        [HttpGet]
        [Route("DeleteCustomer/{id}")]
        public bool DeleteCustomer(int id)
        {
            return customerService.DeleteCustomer(id);
        }

    }
}
