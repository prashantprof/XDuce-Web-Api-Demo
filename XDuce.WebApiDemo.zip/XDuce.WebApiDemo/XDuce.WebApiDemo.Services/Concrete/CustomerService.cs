﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XDuce.WebApiDemo.Models;
using XDuce.WebApiDemo.Repositories.Abstract;
using XDuce.WebApiDemo.Repositories.Concrete;
using XDuce.WebApiDemo.Repositories.Entities;
using XDuce.WebApiDemo.Services.Abstract;

namespace XDuce.WebApiDemo.Services.Concrete
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository repository = null;

        #region Dependency Injection

        public CustomerService() : this(new CustomerRepository()) { }

        public CustomerService(ICustomerRepository respository)
        {
            this.repository = respository;
        }

        #endregion

        public bool DeleteCustomer(int id)
        {
            try
            {
                return repository.DeleteCustomer(id);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public IEnumerable<CustomerModel> GetAllCusotmers()
        {
            List<CustomerModel> result = new List<CustomerModel>();
            try
            {
                var customers = repository.GetAllCusotmers();

                if (customers != null && customers.Any())
                {
                    result = customers.Select(customer => new CustomerModel()
                    {
                        Id = customer.Id,
                        FirstName = customer.FirstName,
                        LastName = customer.LastName,
                        Email = customer.Email,
                        MemberSince = customer.MemberSince
                    }).ToList();
                }

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public CustomerModel GetCustomerById(int id)
        {
            CustomerModel model = null;
            try
            {
                var customer = repository.GetCustomerById(id);

                if (customer != null)
                {
                    model = new CustomerModel()
                    {
                        Id = customer.Id,
                        FirstName = customer.FirstName,
                        LastName = customer.LastName,
                        Email = customer.Email,
                        MemberSince = customer.MemberSince
                    };
                }

                return model;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool SaveCustomer(CustomerModel customer)
        {
            Customer newCustomer = null;
            try
            {
                newCustomer = new Customer()
                {
                    Id = customer.Id,
                    FirstName = customer.FirstName,
                    LastName = customer.LastName,
                    Email = customer.Email,
                    MemberSince = DateTime.Now
                };

                if (newCustomer.Id == 0)
                {
                    if (repository.AddCustomer(newCustomer) > 0)
                        return true;
                }
                else
                {
                    return repository.UpdateCustomer(newCustomer);
                }

                return false;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
