﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XDuce.WebApiDemo.Models;

namespace XDuce.WebApiDemo.Services.Abstract
{
    public interface ICustomerService
    {
        IEnumerable<CustomerModel> GetAllCusotmers();

        CustomerModel GetCustomerById(int id);

        bool SaveCustomer(CustomerModel customer);

        bool DeleteCustomer(int id);
    }
}
